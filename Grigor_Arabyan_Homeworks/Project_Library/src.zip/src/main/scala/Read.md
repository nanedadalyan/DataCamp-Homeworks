The Project Is in Scala.Scala file, just run and use the interactive menu in Command Line.
Other files was for my testing purposes, there are not neccesary .