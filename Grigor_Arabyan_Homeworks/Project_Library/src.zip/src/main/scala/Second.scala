import java.time.format.DateTimeFormatter

object Second extends App{
//  var books = collection.mutable.Map[String, collection.mutable.Map[String,String]]()
//  books += ("Bible" -> collection.mutable.Map("Cal" -> "copies", "count" -> "4"))
//  books += ("Potter" -> collection.mutable.Map("Cal" -> "copies", "count" -> "1"))
//  books += ("Lotr" -> collection.mutable.Map("Cal" -> "copies", "count" -> "0"))
//  println(books)
//
//  print(books.keySet.exists(_=="Bible"))
//  print((books("Bible")("count")).toInt)
//
//  import org.joda.time.DateTime
//  var today = DateTime.now
//  println(today.getClass, today)
//  var change = today.toString()
//  print(change.getClass, change)

//  var parser = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")
//  var stringed = today.toString()
//
//  DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")
//var dateFormatGeneration: DateTimeFormatter = DateTimeFormatter
    import org.joda.time.DateTime
    import org.joda.time.format.DateTimeFormat
//---------

  import org.joda.time.DateTime
  import org.joda.time.format.DateTimeFormat
  import org.joda.time._
  //    getting datetimenow
  var today = DateTime.now
  println(today)
  var date_pattern = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ssZ")
  var d1 =  ((DateTime.now).toString).getClass
  println(d1)
  Thread.sleep(70000)
  var d2 = (DateTime.now).toString
  println(d2)
  var d3 = DateTime.parse(d2)
  println(d3.getClass, "gere")
//-----------
 var comp1 = DateTime.now
  Thread.sleep(70000)
  var comp2 = DateTime.now
  var res = comp2.getSecondOfDay - comp1.getSecondOfDay
  println(res)
  if (res <= 2) {
    print("Yeah", res)
  }else {
    print("Nooo")
  }
}