object Test extends App {
  import scala.collection.mutable.Map
  import org.joda.time.DateTime
  import org.joda.time.format.DateTimeFormat
  import org.joda.time._

  var books = collection.mutable.Map[String, collection.mutable.Map[String,String]]()
  var d2 = (DateTime.now).toString
  books += ("Al" -> collection.mutable.Map("nini" -> "anan"))
  println(books)
  books += ("FL" -> collection.mutable.Map("kok" -> "3"))
  books += ("NY" -> collection.mutable.Map("washington" -> "subscribed"))
  println(books)
//  books  = books.-("Al")
  println(books,"Here")
  books("Al") += ("Porto" -> "Lisbon")
  println(books)
  books("Al") -= ("Porto")
  println(books)
  //  for ((k,v) <- books){
//    for((i,j) <- v){
//      if (j == "subscribed"){
//        println(i)
//      }
//    }
//  }
  //  printf("key: %s, value: %s\n", k, v)
}
