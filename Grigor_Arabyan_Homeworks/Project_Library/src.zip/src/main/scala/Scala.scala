import Test.books

object Scala extends App {
  import scala.collection.mutable.Map
  import util.control.Breaks._
  import org.joda.time.DateTime
  import org.joda.time.format.DateTimeFormat
  import org.joda.time._



var books = collection.mutable.Map[String, collection.mutable.Map[String,String]]()
var students = collection.mutable.Map[String, collection.mutable.Map[String,String]]()

  class Library() {
// this method asks from a user inputs  for the book information when you choose add book on menu
    def addBook(): Unit = {
      var title = scala.io.StdIn.readLine("What is title of the book?")
      var page = scala.io.StdIn.readLine("How many pages does the book have?")
      var copies = scala.io.StdIn.readLine("How many copies of the book there are??")
      books += (title -> collection.mutable.Map("title" -> title, "page" -> page, "copies" -> copies))
      println(books)
    }
    def addUser(): Unit = {
      var generate_id = scala.util.Random
      var generated_id = ((generate_id.nextInt(9999999))).toString
      var name = scala.io.StdIn.readLine("Input a name for the user")
      students += (name -> collection.mutable.Map("fines" -> "0"))
      println(students)
    }
    def checkoutBook(): Unit = {
      var user = scala.io.StdIn.readLine("please tell who wants to check out the book : name ?")
      var book_to_check_out = scala.io.StdIn.readLine("Which book you want to checkout ?")
      if (books.keySet.exists( _ == book_to_check_out) && students.keySet.exists( _ == user)){
        println("Congrads")
        if ((books(book_to_check_out)("copies")).toInt >= 1){
          print("Congrats, there are available counts")
          var saved_date =  (DateTime.now).toString
          students(user) += (book_to_check_out -> saved_date)
          println(students)
          books(book_to_check_out)("copies")  = ((books(book_to_check_out)("copies").toInt) - 1).toString
          println(books)
        }
        else{println("There is not available books go to menu and reserve")}
      }else{
        println("You have printed a book or a user name that does not exist in our lab.")
      }
    }
    def reserveBook(): Unit = {
      var user = scala.io.StdIn.readLine("Name of the student?")
      var book_to_reserve = scala.io.StdIn.readLine("Name of the book?")
      if ((books(book_to_reserve)("copies")).toInt <= 1 && students.keySet.exists(_== user)) {
        students(user) += (book_to_reserve -> "subscribed")
        println(students)
      }else{println("It did not work ")}
    }

    def returnBook(): Unit = {
      var user = scala.io.StdIn.readLine("who wants to return the book? :name ")
      var book_to_return = scala.io.StdIn.readLine("Which book you want to return ")
      if (students.keySet.exists( _ == user) && students(user).keySet.exists(_==book_to_return)){
            students(user) -= (book_to_return)
            books(book_to_return)("copies") = ((books(book_to_return)("copies").toInt) + 1).toString
        print(students)
        print(students(user))
      }
    }
    def notificationBooks() : Unit = {
      var book_to_check = scala.io.StdIn.readLine("which book you want to check for subscribers?")
      for ((k,v) <- students){
        for((i,j) <- v){
          if (j == "subscribed" && i == book_to_check){
            println("User  " + k + " has subscribed " + i + " book ")
          } else {println( "There is not such kind of book")}
        }
      }
    }
    def notificationReserved() : Unit = {
      for ((k,v) <- students){
        for((i,j) <- v){
          if (j == "subscribed"){
            println("User  " + k + " has subscribed " + i + " book ")
            if( (books(i)("copies")).toInt >= 1){
              students(k) -= (i)
            }
          } else {println( "There is not such kind of book")}
        }
      }
    }
    def overdueBooks() : Unit = {
//      Loop over the Library to find book, then loop in users to check if there is the name of that book ? then check that's value not to be "subscribed"
      var user_name = scala.io.StdIn.readLine("enter the name of the USER to check if He has an overdue book?")
      for ((each_book, v) <- books) {
            if (students(user_name).keySet.exists(_ == each_book) && students(user_name)(each_book) != "subscribed"){
              if (students(user_name)(each_book) != "subscribed"){
                var users_time = students(user_name)(each_book)
                var d3 = DateTime.parse(users_time)
                var current_time = DateTime.now
                var diff = current_time.getSecondOfDay - d3.getSecondOfDay
                if (diff >= 55){
                  print("This books that are overdue" + students(user_name)(each_book) )
                }
              }
        }
      }
    }
    def overdueFines(): Unit = {
      var user_name = scala.io.StdIn.readLine("enter the name of the USER to check if He has an overdue book?")
      for ((each_book, v) <- books) {
        if (students(user_name).keySet.exists(_ == each_book) && students(user_name)(each_book) != "subscribed"){
          if (students(user_name)(each_book) != "subscribed"){
            var users_time = students(user_name)(each_book)
            var d3 = DateTime.parse(users_time)
            var current_time = DateTime.now
            var diff = current_time.getSecondOfDay - d3.getSecondOfDay
            if (diff >= 55){
//              print("This books that are overdue" + students(user_name)(each_book) )
              var fine_amount = (diff/55) * 5
              students(user_name)("fines") = ((students(user_name)("fines")).toInt + fine_amount).toString()
              println(students)
            }
          }
        }
      }
    }
    def totalFine(): Unit = {
      var user_for_fine = scala.io.StdIn.readLine("which users fines you want to know ? ")
//      for ((k, v) <- students(user_for_fine)){
        if (students(user_for_fine)("fines") != "0"){
          print("User has " + students(user_for_fine)("fines") + " fines ")
        }
//      }
    }
    def  availableBook(): Unit = {
      var book_to_check = scala.io.StdIn.readLine("Enter the Name of the book")
      if (books.keySet.exists(_== book_to_check)){
        if (books(book_to_check)("copies") != "0"  ){
          println(" The Book " + book_to_check + " Is available")
        }
      }else{
        println("There are not available copies of this book")
      }
    }

    def usersCheckedOut():  Unit = {
      for ( (k,v) <- books){
        for ((i,j) <- students){
          if ( j.keySet.exists(_ == k)){
            if (students(i)(k) != "subscribed"){
              println("The user " + i + " Has checked out " + k + " Book ")
            }
          }
        }
      }
    }
    def removeBook(): Unit = {
      var book_to_remove = scala.io.StdIn.readLine("Input the book you want to remove from Library")
      if (books.keySet.exists(_ == book_to_remove)){
        books  = books.-(book_to_remove)
        println("Congrats the book is removed")
        println(books)
      }else{println("the book does not exist in Library")}
    }
    def removeUser(): Unit = {
      var user_to_remove = scala.io.StdIn.readLine("Which user to remove ?")
      if (students.keySet.exists(_ == user_to_remove)) {
        students = students.-(user_to_remove)
        println("congrats your user is removed")
        println(students)
      }else{println("the user does not exist in Library")}
    }
  }
    while (true) {
      println("Enter On of the Letters to do the action you want  \n",
         "add_book          : Enter to add book in Library\n",
        "add_user           : Enter a name to add a user\n",
        "checkout_book      : Enter  to checkout book \n",
        "reserve book       : If there are not available copies you can reserve book\n",
        "return book        : If you want to Return a book\n",
        "return book        : If you want to Return a book\n",
        "notification       : Get the list of users that have put the book on reserve  \n",
        "notification res   : Get list of books that have been reserved by user and became available recently.  \n",
        "                   The notification is shown only once after book becomes available, after displaying the notification it is deleted  \n",
        "overdue books      : Get list of books that are overdue (more than 55 Seconds checked out by the user)\n",
        "overdue fines      :  Get fine for the given book (5$ each 55 sec overdue) for the user  \n",
        "total fine         :  Get total fine for all the overdue books of the user \n",
        "available books    :  Check if available copy of book is present\n",
        "users checkedout   :  Get list of users that have checked out given book\n",
        "delete book        :  Delete a book from Library\n",
        "delete book        :  Delete a user \n")
      var menu_input = scala.io.StdIn.readLine("Input one of the options Below")

      if (menu_input == "add book") {
        val student1: Library = new Library()
        student1.addBook()
      } else if (menu_input == "add user") {
        val student1: Library = new Library()
        student1.addUser()
      } else if (menu_input == "checkout book") {
        val temp: Library = new Library()
        temp.checkoutBook()
      } else if (menu_input == "overdue books") {
       val temp: Library = new Library()
       temp.overdueBooks()
      }
      else if (menu_input == "delete book") {
        val temp: Library = new Library()
        temp.removeBook()
      }else if (menu_input == "delete user"){
        val temp: Library = new Library()
        temp.removeUser()
      }else if (menu_input == "return book"){
        val temp: Library = new Library()
        temp.returnBook()
      }else if(menu_input == "notification"){
        val temp: Library = new Library()
        temp.notificationBooks()
      }else if(menu_input == "overdue fines"){
        val temp: Library = new Library()
        temp.overdueFines()
      }else if (menu_input == "total fine"){
        val temp: Library = new Library()
        temp.totalFine()
      }else if  (menu_input == "available books"){
        val temp: Library = new Library()
        temp.availableBook()
      }else if (menu_input == "users checkedout"){
        val temp: Library = new Library()
        temp.usersCheckedOut()
      }
      else if(menu_input == "notification res"){
        val temp: Library = new Library()
      temp.notificationReserved()
      }
      else if (menu_input == "reserve book"){
        val temp: Library = new Library()
        temp.reserveBook()
      }
      else if (menu_input == "exit") {
        println("going out")
        break
      }
    }
  }