package project_Sharing_Journey

object City extends Enumeration {
  type City = Value
  val Yerevan, Gyumri, Vanadzor, Vagharshapat, Abovyan,
  Kapan, Hrazdan, Armavir, Artashat, Ijevan, Gavar,
  Goris, Charentsavan, Ararat, Masis, Artik, Sevan, Ashtarak,
  Dilijan, Sisian, Alaverdi, Stepanavan, Martuni, Spitak,
  Vardenis, Yeghvard, Vedi, Byureghavan, Nor_Hachn, Metsamor,
  Berd, Yeghegnadzor, Tashir, Kajaran, Vayk, Chambarak, Maralik,
  Noyemberyan, Talin, Jermuk, Meghri, Ayrum, Akhtala, Tumanyan,
  Tsaghkadzor = Value
}
