package project_Sharing_Journey

object Driver_Status extends Enumeration {
  type Driver_Status = Value
  val Free, Booked = Value
}
