package project_Sharing_Journey

object Passenger_Status extends Enumeration {
  type Passenger_Status = Value
  val Searching, Found = Value
}
