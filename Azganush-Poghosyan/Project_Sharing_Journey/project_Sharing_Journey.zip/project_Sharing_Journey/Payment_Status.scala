package project_Sharing_Journey

object Payment_Status extends Enumeration {
  type Payment_Status = Value
  var Paid, Received, Accepted= Value
}
